import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

import oracle.oats.scripting.modules.basic.api.IteratingVUserScript;
import oracle.oats.scripting.modules.basic.api.MatchOption;
import oracle.oats.scripting.modules.basic.api.ScriptService;
import oracle.oats.scripting.modules.basic.api.TextPresence;
import oracle.oats.scripting.modules.browser.api.BrowserSettings.BrowserType;
import oracle.oats.scripting.modules.functionalTest.api.PropertyTestList;
import oracle.oats.scripting.modules.webdom.api.Source;
import oracle.oats.scripting.modules.webdom.api.elements.DOMElement;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;

public class script2 extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;

	public void initialize() throws Exception {
		browser.setBrowserType(BrowserType.Chrome);
		browser.launch();
		browser.clearBrowser();
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
		
		/**
		 * Step1: hit the required application url
		 */
		                                              
		
		/*get the title of the laanding page */
		                                                                                                  
		/* verify the landing page */
		                                                                                                                                           

		/**
		 * Step2: Search required product
		 */
		                                       
		
		/** 
		 * Step3: select 'H�chster Preis' from dropdown 
		 */
		info("start");
		setFilter("H�chster Preis");
				
		/** Step4: verify search result message */
//		String searchedResult=web.element("/web:window[@index='0']/web:document[@index='0']/web:h1[@class='pop-main__title' or @index='0']").getDisplayText();
//		web.assertText("Suchergebnis f�r \"trampoline\"",searchedResult,Source.DisplayContent,TextPresence.PassIfPresent,MatchOption.Exact);		
//				
//		/** Step5: Identify the common parent */
//		selectProductUnderGivenAmount(1000);
//		
//		/** Step6: click on 'In den Warenkorb' */
//		web.button("/web:window[@index='0']/web:document[@index='0']/web:span[@text='In den Warenkorb']").click();
//		
//		/** Step7: get sucess message */
//		validateSuccessPopup();
//		/* close popup */
//		web.button("/web:window[@index='0' or @title='Freebound Trampolin &quot;BOWL&quot;, plum | myToys']/web:document[@index='0']/web:button[@text='Overlay schlie�en' or @index='30']").click();
	}

	public void finish() throws Exception {
		
		//browser.closeAllBrowsers();
		
	}
	
	public void enterApplicationUrl(String url)throws Exception{
		/** Step1: enter application URL */
		web.window("/web:window[@index='0' or @title='https://www.mytoys.de']").navigate(url);
		/* wait for page load */
		web.window("/web:window[@index='0' or @title='https://www.mytoys.de']").waitForPage(100,true);
	}
	
	public void searchForRequiredProduct(String productToBeSearched)throws Exception{
		/** Step2: type for 'trampoline' in the search input field */
		web.textBox("/web:window[@index='0' or @title='myToys Online Shop | Einfach alles f�r Ihr Kind']/web:document[@index='0']/web:form[@index='0']/web:input_search[@index='0']").click();
		
		web.textBox("/web:window[@index='0' or @title='myToys Online Shop | Einfach alles f�r Ihr Kind']/web:document[@index='0']/web:form[@index='0']/web:input_search[@index='0']").setText(
			productToBeSearched);
		/* click on search icon */
		web.button("/web:window[@index='0' or @title='myToys Online Shop | Einfach alles f�r Ihr Kind']/web:document[@index='0']/web:form[@index='0']/web:button[@index='2']").click();
	}
	
	public void setFilter(String filter)throws Exception{
		web.selectBox("/web:window[@index='0' or @title='trampoline | myToys']/web:document[@index='0']/web:select[(@name='select' or @index='0') and multiple mod 'false']").selectOptionByText(
		filter);
	}
	
	public void selectProductUnderGivenAmount(int price)throws Exception{
		PropertyTestList ptList = new PropertyTestList();
		ptList.add("classname",	"prod-tile__price-container");
		/* get the list of products */
		List<DOMElement> eles = web.document("/web:window[ @title='trampoline | myToys']/web:document[@index='0']").getElementsByTagName("div",ptList);

		for (int i = 0; i < eles.size(); i++) {
			if (eles.get(i).getChildren().size() == 1) {

				Number amount = NumberFormat.getNumberInstance(Locale.GERMAN).parse(eles.get(i).getDisplayText().replace(" �",""));
				info("Content:" + amount);
				if (amount.doubleValue() < price) {
					eles.get(i).click();
					break;
				}

			} else if (eles.get(
				i).getChildren().size() == 2) {
				Number amount = NumberFormat.getNumberInstance(Locale.GERMAN).parse(eles.get(i).getChildren().get(1).getDisplayText().replace(" �",""));
				info("Content:" + amount);
				if (amount.doubleValue() < price) {
					eles.get(i).click();
					break;
				}
			} else if (eles.get(
				i).getChildren().size() == 3) {

				Number amount = NumberFormat.getNumberInstance(Locale.GERMAN).parse(eles.get(i).getChildren().get(2).getDisplayText().replace(" �",	""));
				info("Content:" + amount);
				if (amount.doubleValue() < price) {
					eles.get(i).click();
					break;
				}
			}
		}
	}
	public void validateSuccessPopup()throws Exception{
		String sucessMsg = web.element("/web:window[@index='0']/web:document[@index='0']/web:div[@class='msg-success js-msg-add' or @index='390']").getDisplayText();
		/* validate the sucess message */
		web.assertText("Der Artikel wurde Ihrem Warenkorb hinzugef�gt.",sucessMsg,Source.DisplayContent,TextPresence.PassIfPresent,MatchOption.Exact);
		/* validate the sucess icon */
		String sucessIcon = Boolean.toString(web.element("/web:window[@index='0']/web:document[@index='0']/web:div[@class='msg-success-icon js-msg-add' or @index='389']").isDisplayed());
		web.assertText("true",sucessIcon,Source.DisplayContent,TextPresence.PassIfPresent,MatchOption.Exact);
	}
}
